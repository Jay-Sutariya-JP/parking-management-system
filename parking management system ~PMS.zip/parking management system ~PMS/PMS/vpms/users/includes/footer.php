  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                   
                    <div class="col-sm-12 text-center">
                    © 2025 All Rights Reserved By J & P .CO
                    </div>
                </div>
            </div>
        </footer>