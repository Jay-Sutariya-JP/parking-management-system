<!DOCTYPE html>
<html lang="en">
    <head>
        
        <title>Vehicle Parking Management System|| Home Page</title>
        
        <!-- Font Awesome icons (free version)-->
        <script src="https://use.fontawesome.com/releases/v6.1.0/js/all.js" crossorigin="anonymous"></script>
        <!-- Google fonts-->
        <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700" rel="stylesheet" type="text/css" />
        <link href="https://fonts.googleapis.com/css?family=Lato:400,700,400italic,700italic" rel="stylesheet" type="text/css" />
        <!-- Core theme CSS (includes Bootstrap)-->
        <link href="css/styles.css" rel="stylesheet" />
        <link href="css/body.css" rel="stylesheet" />
        
    </head>
    <body id="page-top">
        <!-- Navigation-->
        <nav class="navbar navbar-expand-lg bg-secondary text-uppercase fixed-top" id="mainNav">
            <div class="container">
                <a class="navbar-brand" href="index.php">Parking Managemetn System ~PMS</a>
                <button class="navbar-toggler text-uppercase font-weight-bold bg-primary text-white rounded" type="button" data-bs-toggle="collapse" data-bs-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
                    Menu
                    <i class="fas fa-bars"></i>
                </button>
                <div class="collapse navbar-collapse" id="navbarResponsive">
                    <ul class="navbar-nav ms-auto">
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="admin/index.php">Admin</a></li>
                        <li class="nav-item mx-0 mx-lg-1"><a class="nav-link py-3 px-0 px-lg-3 rounded" href="users/login.php">Users</a></li>
                       
                    </ul>
                </div>
            </div>
        </nav>
        <!-- Masthead-->
       
       
        <div class="hero_area">
    <div class="bg-box">
      <img src="assets/home/carbg.png" alt="">
    </div>
    <!-- header section strats -->
    <header class="header_section">
      <div class="container">
        <nav class="navbar navbar-expand-lg custom_nav-container ">
          <a class="navbar-brand" href="index.html">
            <span>
              Paspark
            </span>
          </a>

          <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
            <span class=""> </span>
          </button>
        </nav>
      </div>
    </header>
    <!-- slider section -->
    <section class="slider_section ">
      <div class="container pt-5">
        <div class="detail-box col-md-9 mx-auto px-0">
          <h1>
            Finding Parking Lots Made Easy
          </h1>
          <p>
          Developing an innovative Parking Management System to streamline parking space allocation, optimize vehicle flow, and enhance user experience through real-time availability tracking.
          </p>
        </div>
      </div>
    </section>
    <!-- end slider section -->
  </div>

  <!-- about section -->

  <section class="about_section layout_padding">
    <div class="container  ">
      <div class="heading_container ">
        <h2>
          About Us
        </h2>
        <p>
        "Revolutionizing Parking Management with Smart, Efficient, and Sustainable Solutions for Modern Cities."
        </p>
      </div>
      <div class="row">
        <div class="col-lg-6 ">
          <div class="img-box">
           <img src="assets/home/about-img1.jpg" alt="">
          
          </div>
        </div>
        <div class="col-lg-6">
          <div class="detail-box">
            <h3>
              We Are Here For Help
            </h3>
            <p class="text-right">
            At J & P co., we are dedicated to revolutionizing parking management with smart, efficient solutions. Our Parking Management System utilizes cutting-edge technology to optimize space allocation, reduce congestion, and enhance user convenience. By integrating real-time data, smart sensors, and mobile features, we help both drivers and facility operators improve efficiency while minimizing environmental impact. We strive to create seamless parking experiences for urban communities, aiming for smarter cities and a sustainable future. Whether for a single lot or multiple locations, our solutions are scalable, adaptable, and designed to meet the unique needs of modern infrastructure.
            </p>
            <p>
            At J & P .co, we provide innovative parking management solutions using real-time data and seamless mobile integration to optimize space, reduce congestion, and enhance user experience. Our mission is to create efficient, sustainable, and user-friendly parking systems for modern urban environments.
            </p>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end about section -->

  <!-- why section -->

  <section class="why_section layout_padding-bottom">
    <div class="container">
      <div class="col-md-10 px-0">
        <div class="heading_container">
          <h2>
            Why <span class="text-info"> Choose  </span> Us
          </h2>
          <p>
          "Choose us for cutting-edge parking solutions that optimize space, reduce congestion, and enhance convenience. Our scalable, tech-driven system ensures a seamless, sustainable parking experience for both operators and users."
          </p>
        </div>
      </div>
      <div class="row">
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="assets/home/w1.png" alt="">
            </div>
            <div class="detail-box">
              <h4>
                No Booking Fees
              </h4>
              <p>
              With our Parking Management System, there are no hidden banking fees or transaction charges, ensuring cost-efficiency for both users and operators. We prioritize transparency and affordability, so you can manage parking without worrying about additional financial burdens. 
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box">
            <div class="img-box">
              <img src="assets/home/w4.png" alt="">
            </div>
            <div class="detail-box">
              <h4>
                Data Security
              </h4>
              <p>
              We prioritize the privacy and security of your personal information. Our Parking Management System uses advanced encryption protocols and secure servers to protect user data from unauthorized access, ensuring a safe and trustworthy experience for all users.
              </p>
            </div>
          </div>
        </div>
        <div class="col-md-6 col-lg-4 mx-auto">
          <div class="box ">
            <div class="img-box">
              <img src="assets/home/w3.png" alt="">
            </div>
            <div class="detail-box">
              <h4>
                Simple Booking Process
              </h4>
              <p>
                Our user-friendly booking system allows customers to easily reserve parking spaces with just a few clicks. Whether through our app or website, booking a spot is quick, hassle-free, and designed for maximum convenience. so this is userfriendly and not to hard for book.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end why section -->

  <!-- pricing section -->

  <section class="pricing_section layout_padding">
    <div class="bg-box">
      <img src="assets/home/pricing-bg1.png" alt="">
    </div>
    <div class="container">
      <div class="heading_container heading_center">
        <h2>
          Our Pricing
        </h2>
      </div>
      <div class="col-xl-10 px-0 mx-auto">
        <div class="row">
          <div class="col-md-6 col-lg-4 mx-auto">
            <div class="box">
              <h4 class="price">
              ₹20
              </h4>
              <h5 class="name">
                Low Width
              </h5>
              <p>
              Basic Pricing For just ₹20, our basic plan offers essential parking management features like real-time space tracking and secure booking, making it a cost-effective solution for smaller lots or individual users.
              </p>
              <img src="./assets/home/bike.png" alt="" class="img-fluid w-75">
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mx-auto">
            <div class="box box-center">
              <h4 class="price">
              ₹50
              </h4>
              <h5 class="name">
                High Width
              </h5>
              <p>
              For ₹50, unlock additional high-end features such as custom reporting, extended integrations, and priority support, perfect for businesses looking to scale their parking operations with ease and efficiency.
              </p>
              <img src="./assets/home/truck.png" alt="" class="img-fluid w-75">
            </div>
          </div>
          <div class="col-md-6 col-lg-4 mx-auto">
            <div class="box">
              <h4 class="price">
              ₹30
              </h4>
              <h5 class="name">
                Medium Width
              </h5>
              <p>
              At ₹30, our mid-tier plan provides essential features like real-time tracking, secure reservations, and basic reporting, making it ideal for businesses seeking a balance between functionality and affordability.
              </p>
              <img src="./assets/home/car1.png" alt="" class="img-fluid w-75">
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end pricing section -->


  <!-- client section -->

  <section class="client_section layout_padding">
    <div class="container">
      <div class="heading_container col">
        <h2>
          What Says Our <span class="text-info">Client</span>
        </h2>
      </div>
      <div class="client_container">
        <div class="carousel-wrap ">
          <div class="owl-carousel client_owl-carousel">
            <div class="item pb-5">
              <div class="box">
                <div class="detail-box">
                  <p class="ps-5 pe-5">
                  "Our experience with [Your Company Name] has been exceptional. The parking system is easy to use, efficient, and has significantly improved our operations. The customer support team is always responsive, making parking management hassle-free for both our team and users."
                  </p>
                </div>
                <div class="client_id">
                  <div class="img-box">
                    <img src="assets/home/c1.jpg" alt="" class="img-1">
                  </div>
                  <div class="name">
                    <h6>
                    John Davis
                    </h6>
                    <p>
                    Texas
                    </p>
                  </div>
                </div>
              </div>
            </div>
            <div class="item">
              <div class="box">
                <div class="detail-box">
                  <p class="ps-5 pe-5">
                  "Working with [Your Company Name] has been a game-changer for our business. The parking management system is intuitive, reliable, and has streamlined our entire process. It’s easy to manage and has improved our customers’ experience significantly."
                  </p>
                </div>
                <div class="client_id">
                  <div class="img-box">
                    <img src="assets/home/c2.jpg" alt="" class="img-1">
                  </div>
                  <div class="name">
                    <h6>
                    Sara Lee
                    </h6>
                    <p>
                    California
                    </p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- end client section -->

  <!-- new section start  -->

  
  <div class="hero_area">
    <div class="container-fluid">
    <div class="row justify-content-evenly">  <div class="col-md-12"><h3 class="ps-5 pb-5" > Our <span class="text-info">Facility </span>.</h3></div>
      <div class="col-md-2 text-center">
    <div class="card border-primary mb-3" style="max-width: 18rem;">
      <div class="card-header">Facility</div>
      <div class="card-body text-primary">
      <h5 class="card-title">24*7</h5>
      <div class="">
        <img src="assets/home/24.jpg" alt="" class="img-fluid">
      </div>
      <p class="card-text">Our parking lot remains open and fully accessible 24 hours a day, 7 days a week, ensuring you never have to worry about finding a spot at any time.
      .</p>
      </div>
    </div>
      </div>
      <div class="col-md-2 text-center">
      <div class="card border-secondary mb-3" style="max-width: 18rem;">
      <div class="card-header">Facility</div>
      <div class="card-body text-secondary">
      <h5 class="card-title">CCTV</h5>
      <div class="">
        <img src="assets/home/cctv.jpg" alt="" class="img-fluid bg-transparent">
      </div>
      <p class="card-text">Our parking facility uses advanced CCTV cameras for 24/7 surveillance, providing continuous monitoring to ensure the security of your vehicle.</p>
      </div>
    </div>
      </div>
      <div class="col-md-2 text-center">
      <div class="card border-danger mb-3" style="max-width: 18rem;">
      <div class="card-header">Fire Safety</div>
      <div class="card-body text-danger">
      <h5 class="card-title">Fire</h5>
      <div class="">
        <img src="assets/home/fire.jpg" alt="" class="img-fluid">
      </div>
      <p class="card-text">fire safety measures to protect both vehicles and individuals. Strategically placed fire extinguishers, smoke detectors, and emergency exit routes ensure quick action in case of an emergency. 
      .</p>
      </div>
    </div>
      </div>
      <div class="col-md-2 text-center">
      <div class="card border-warning mb-3" style="max-width: 18rem;">
      <div class="card-header">Facility</div>
      <div class="card-body text-warning">
      <h5 class="card-title">Customer Support</h5>
      <div class="">
        <img src="assets/home/customer-support.avif" alt="" class="img-fluid">
      </div>
      <p class="card-text">Our parking facility offers round-the-clock customer support to ensure a smooth and hassle-free experience for all users.      .</p>
      </div>
    </div>
      </div>
      <div class="col-md-2 text-center">
      <div class="card border-dark mb-3" style="max-width: 18rem;">
      <div class="card-header">Facility</div>
      <div class="card-body text-dark">
      <h5 class="card-title">Restroom Facilities</h5>
      <div class="">
        <img src="assets/home/restroom.jpg" alt="" class="img-fluid">
      </div>
      <p class="card-text"> Regular cleaning schedules are followed to maintain high standards of cleanliness, providing a pleasant experience for all users  our restroom facilities offer a comfortable.</p>
      </div>
    </div>
      </div>
      </div>
    </div>
    <!-- header section strats -->
    <div class="container-fluid pb-5 pt-3 mb-5">

    </div>
    <!-- end slider section -->
  </div>

  <!-- new section end  -->

  <!-- info section -->
  <section class="info_section">

    <div class="container">
      <div class="info_top ">
        <div class="row ">
          <div class="col-md-6 col-lg-3 info_col">
            <div class="info_form">
              <h4 class="pb-5">
                Stay Connected
              </h4>

              <div class="social_box">
                <a href="">
                   <img src="./assets/home/facebook-circle-svgrepo-com.png" alt="" class="img-fluid w-100">
                </a>
                <a href="">
                  <!-- <i class="fa fa-twitter" aria-hidden="true"></i> -->
                   <img src="./assets/home/twitter-svgrepo-com.png" alt="" class="img-fluid w-100">
                </a>
                <a href="">
                  <!-- <i class="fa fa-linkedin" aria-hidden="true"></i> -->
                  <img src="./assets/home/linkedin-1-svgrepo-com.png" alt="" class="img-fluid w-100 rounded-circle">
                </a>
                <a href="">
                  <!-- <i class="fa fa-instagram" aria-hidden="true"></i> -->
                  <img src="./assets/home/instagram-svgrepo-com.png" alt="" class="img-fluid w-100">
                </a>
              </div>
            </div>
          </div>
          <div class="col-md-6 col-lg-3 info_col ">
            <div class="info_detail">
              <h4>
                About Us
              </h4>
              <p>
                Necessitatibus, culpa, totam quod neque cum officiis odio, excepturi magnam incidunt voluptates sed voluptate id expedita sint! Cum veritatis iusto molestiae reiciendis deserunt vel odio incidunt, tenetur itaque. Ullam, iste!
              </p>
            </div>
          </div>
        
          <div class="col-md-6 col-lg-3 info_col">
            <h4>
              Contact us
            </h4>
            <p>
              Lorem ipsum dolor sit amet consectetur adipisicing elit
            </p>
            <div class="contact_nav">
              <a href="">
                <i class="fa fa-map-marker" aria-hidden="true"></i>
                <span>
                  Waghavadi Road Bhavngar
                </span>
              </a>
              <a href="">
                <i class="fa fa-phone" aria-hidden="true"></i>
                <span>
                  Call : +91 9409810285
                </span>
              </a>
              <a href="">
                <i class="fa fa-envelope" aria-hidden="true"></i>
                <span>
                  Email : pms@gmail.com
                </span>
              </a>
            </div>
          </div>


           
          <div class="col-md-6 col-lg-3 info_col">
            <h4>Maps </h4>
          <div class="">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d59290.84830250038!2d72.06574934863282!3d21.754004900000005!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3958c020ac9375d5%3A0xa7af0d9ab1ed8c50!2sBAPS%20Shri%20Swaminarayan%20Mandir%2C%20Bhavnagar!5e0!3m2!1sen!2sin!4v1738215324725!5m2!1sen!2sin" width="400" height="300" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
            </div>
          </div>


        </div>
      </div>
    </div>
  </section>
  <!-- end info_section -->

  <!-- new demo  -->



  <!-- new demo end  -->

       
      
        <!-- Copyright Section-->
        <div class="copyright py-4 text-center text-white">
            <div class="container"><small>© 2025 All Rights Reserved By J & P .CO</small></div>
        </div>
        <!-- Bootstrap core JS-->
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
        <!-- Core theme JS-->
        <script src="js/scripts.js"></script>
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <!-- * *                               SB Forms JS                               * *-->
        <!-- * * Activate your form at https://startbootstrap.com/solution/contact-forms * *-->
        <!-- * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *-->
        <script src="https://cdn.startbootstrap.com/sb-forms-latest.js"></script>
    </body>
</html>
