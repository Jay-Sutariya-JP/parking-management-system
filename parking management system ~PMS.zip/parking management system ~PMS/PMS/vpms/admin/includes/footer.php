  <footer class="site-footer">
            <div class="footer-inner bg-white">
                <div class="row">
                    
                    <div class="col-sm-6 text-center">
                   <span class="text-danger"> © </span>2025 All Rights Reserved By J & P .CO
                    </div>
                </div>
            </div>
        </footer>